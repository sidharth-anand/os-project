#ifndef PIPE_TRANSPORT_H
#define PIPE_TRANSPORT_H
/*
    Include file for the pipeTransport.c file
*/
void* listen_and_print(void* pipeArg);
void* start_listening(void* pipefdsArg);

#endif